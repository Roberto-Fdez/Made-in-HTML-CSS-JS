let mida = 18; // Mida inicial del text
const textElement = document.getElementById("text");

function augmentarMida() {
    mida += 2;
    textElement.style.fontSize = mida + "px";
}

function disminuirMida() {
    mida -= 2;
    textElement.style.fontSize = mida + "px";
}

function canviarColor() {
    const colors = ["red", "blue", "green", "purple", "orange"];
    const colorAleatori = colors[Math.floor(Math.random() * colors.length)];
    textElement.style.color = colorAleatori;
}
function afegirParagraf() {
    let textUsuari = prompt("Introdueix el text per al nou paràgraf:");
    if (textUsuari) {
        let nouParagraf = document.createElement("p");
        nouParagraf.textContent = textUsuari;
        nouParagraf.classList.add("paragraf-afegit");
        document.getElementById("contenidor-paragrafs").appendChild(nouParagraf);
    }
}

function eliminarParagraf() {
    let contenidor = document.getElementById("contenidor-paragrafs");
    if (contenidor.lastChild) {
        contenidor.removeChild(contenidor.lastChild);
    }
}
function afegirClasse() {
    var classeNova = document.getElementById("classeNova");
    classeNova.classList.add("classeNovaCss");
}
function eliminarClasse() {
    var classeNova = document.getElementById("classeNova");
    classeNova.classList.remove("classeNovaCss");
}
const textOriginal = "Este texto se traduce. CUIDADO QUE TE QUITARÁ EL ACERTIJO ( TENDRAS QUE REINICIAR LA PAGINA PARA PODER VERLO). ";
const textTraduccio = "Aquest text es tradueix. CURA QUE ET TREURÀ L'ENCERTIJO ( HAURÀS DE REINICIAR LA PÀGINA PER PODER VEURE'L).";

const btnTradueix = document.getElementById("tradueix");
btnTradueix.addEventListener("click", function () {
    if (textElement.textContent === textOriginal) {
        textElement.textContent = textTraduccio;
    } else {
        textElement.textContent = textOriginal;
    }
});

const btnMouseover = document.getElementById("mouseover");
btnMouseover.addEventListener("mouseover", function () {
    btnMouseover.style.backgroundColor = "blue";
});
btnMouseover.addEventListener("mouseout", function () {
    btnMouseover.style.backgroundColor = "";
});
